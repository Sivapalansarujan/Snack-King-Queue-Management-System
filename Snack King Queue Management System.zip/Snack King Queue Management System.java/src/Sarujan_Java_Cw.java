import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.time.LocalDate;
import java.time.LocalTime;

public class Sarujan_Java_Cw{
    static String[] counter1 = {"X","X"};
    static String[] counter2 = {"X","X","X"};
    static String[] counter3 = {"X","X","X","X","X"};
    static int Burger = 50;

    public static void main (String[] args)throws IOException{
        allQueues();
        Menu();
    }

    public static void Menu() throws IOException{
        while(true){
            System.out.println();

            if(Burger == 10){
                System.out.println("Burger count is " + Burger);
            }

            System.out.println("--------------------------------");

            LocalDate currentDate = LocalDate.now();
            System.out.println("Date: " + currentDate);

            LocalTime currentTime = LocalTime.now();
            System.out.println("Time: " + currentTime);

            System.out.println("--------------------------------");
            System.out.println("Foodies Fave Food center - Menu");
            System.out.println("--------------------------------");
            System.out.println("100 or VFQ: View all Queues.");
            System.out.println("101 or VEQ: View all Empty Queues.");
            System.out.println("102 or ACQ: Add customer to a Queue.");
            System.out.println("103 or RCQ: Remove a customer from a Queue.");
            System.out.println("104 or PCQ: Remove a served customer.");
            System.out.println("105 or VCS: View Customers Sorted in alphabetical order.");
            System.out.println("106 or SPD: Store Program Data into file.");
            System.out.println("107 or LPD: Load Program Data from file.");
            System.out.println("108 or STK: View Remaining Burger Stock.");
            System.out.println("109 or AFS: Add Burger to Stock.");
            System.out.println("999 or EXT: Exit the Program.");
            System.out.println("--------------------------------");
            System.out.println(" ");

            Scanner input = new Scanner(System.in);
            System.out.println("Please input an choice form the menu:");
            String choice = input.nextLine().toUpperCase();
            System.out.println(" ");

            if(choice.equals("100") || (choice.equals("VFQ"))) {
                allQueues();
            }

            else if(choice.equals("101") || (choice.equals("VEQ"))) {
                allEmptyQueues();
            }

            else if(choice.equals("102") || (choice.equals("ACQ"))) {
                addCustomerToQueues();
                allQueues();
            }

            else if(choice.equals("103") || (choice.equals("RCQ"))) {
                removeCustomerFromQueues();
                allQueues();
            }

            else if(choice.equals("104") || (choice.equals("PCQ"))) {
                removeServedCustomerFromQueues();
                allQueues();
                Burger= Burger - 5;
                System.out.println(" ");

            }

            else if(choice.equals("105") || (choice.equals("VCS"))) {
                sortCustomerName();
            }

            else if(choice.equals("106") || (choice.equals("SPD"))) {
                savedDataToFile();
            }

            else if(choice.equals("107") || (choice.equals("LPD"))) {
                loadDataToTextFile();
            }

            else if(choice.equals("108") || (choice.equals("STK"))) {
                System.out.println("Burger count is "+ Burger);
            }

            else if(choice.equals("109") || (choice.equals("AFS"))) {
                System.out.println("Burger count is "+ Burger);
                Scanner input2 = new Scanner(System.in);
                System.out.println("Please input the number of burger to add:");
                int new_burger = input2.nextInt();
                Burger = Burger + new_burger;
                System.out.println("Burger count is "+ Burger);
                System.out.println(" ");
            }

            else if(choice.equals("999") || (choice.equals("EXT"))) {
                break;
            }

            else {
                System.out.println("Please select a valid option");
            }
        }
    }

    public static void allQueues(){

        System.out.println("*****************");
        System.out.println("*"+"    counters   "+"*");
        System.out.println("*****************");
        System.out.println("c1      c2      c3");

        for (int j = 0; j < counter3.length; j++) {
            try{
                if (counter1[j].equals("X"))
                    System.out.print("X       ");
                else
                    System.out.print("O       ");
            }
            catch(ArrayIndexOutOfBoundsException e){
                System.out.print("        ");
            }

            try{
                if (counter2[j].equals("X"))
                    System.out.print("X       ");
                else
                    System.out.print("O       ");
            }
            catch(ArrayIndexOutOfBoundsException e){
                System.out.print("        ");
            }

            try{
                if (counter3[j].equals("X"))
                    System.out.print("X       ");
                else
                    System.out.print("O       ");
            }
            catch(ArrayIndexOutOfBoundsException e){
                System.out.print("       ");
            }
            System.out.println();
        }
        System.out.println("O: Occupied  X: Not Occupied ");
    }

    public static void allEmptyQueues(){

        System.out.println("*****************");
        System.out.println("*"+"    counters   "+"*");
        System.out.println("*****************");
        System.out.println("c1      c2      c3");

        for (int j = 0; j < counter3.length; j++) {
            try{
                if (counter1[j] == "X"){
                    System.out.print(counter1[j] + "       ");
                }
                else{
                    System.out.print("        ");
                }
            }

            catch(ArrayIndexOutOfBoundsException e){
                System.out.print("        ");
            }

            try{
                if (counter2[j] == "X"){
                    System.out.print(counter2[j] + "       ");
                }
                else{
                    System.out.print("        ");
                }
            }

            catch(ArrayIndexOutOfBoundsException e){
                System.out.print("        ");
            }

            try{
                if (counter3[j] == "X"){
                    System.out.println(counter3[j] + "       ");
                }
                else{
                    System.out.println("        ");
                }
            }

            catch(ArrayIndexOutOfBoundsException e){
                System.out.print("        ");
            }

        }
        System.out.println("O: Occupied  X: Not Occupied ");
    }

    public static void addCustomerToQueues(){

        Scanner input3 = new Scanner(System.in);
        System.out.println("Input the customer name:");
        String name = input3.nextLine();
        System.out.println(" ");


        if (counter1[0] == "X"){
            counter1[0] = name;
        }

        else if (counter2[0] == "X"){
            counter2[0] = name;
        }

        else if (counter3[0] == "X"){
            counter3[0] = name;
        }

        else if (counter1[1] == "X"){
            counter1[1] = name;
        }

        else if (counter2[1] == "X"){
            counter2[1] = name;
        }

        else if (counter3[1] == "X"){
            counter3[1] = name;
        }

        else if (counter2[2] == "X"){
            counter2[2] = name;
        }

        else if (counter3[2] == "X"){
            counter3[2] = name;
        }

        else if (counter3[3] == "X"){
            counter3[3] = name;
        }

        else if (counter3[4] == "X"){
            counter3[4] = name;
        }

        else{
            System.out.println("Please wait.All the queues are full.");
        }
    }

    public static void removeCustomerFromQueues() {
        Scanner input4 = new Scanner(System.in);
        System.out.print("Enter the counter number= 1 or 2 or 3:-");
        int counter = input4.nextInt();
        System.out.print("Enter the removed position ( 1 or 2 or 3 or 4 or 5 ):- ");
        int range = input4.nextInt() - 1;

        if (counter == 1) {
            for(int i  = range; i < counter1.length-1; i++){
                counter1[i] = counter1[i+1];
            }
            counter1[counter1.length-1] = "X";
        }

        else if (counter == 2) {
            for(int i  = range; i < counter2.length-1; i++){
                counter2[i] = counter2[i+1];
            }
            counter2[counter2.length-1] = "X";
        }

        else if (counter == 3) {
            for(int i  = range; i < counter3.length-1; i++){
                counter3[i] = counter3[i+1];
            }
            counter3[counter3.length-1] = "X";
        }
    }


    public static void removeServedCustomerFromQueues() {
        Scanner input5 = new Scanner(System.in);
        System.out.print("Enter the counter number= 1 or 2 or 3:-");
        int counter = input5.nextInt();

        if (counter == 1) {
            for(int i  = 0; i < counter1.length-1; i++){
                counter1[i] = counter1[i+1];
            }
            counter1[counter1.length-1] = "X";
        }

        else if (counter == 2) {
            for(int i  = 0; i < counter2.length-1; i++){
                counter2[i] = counter2[i+1];
            }
            counter2[counter2.length-1] = "X";
        }

        else if (counter == 3) {
            for(int i  = 0; i < counter3.length-1; i++){
                counter3[i] = counter3[i+1];
            }
            counter3[counter3.length-1] = "X";
        }

        Burger = Burger -5;
    }

    public static void sortCustomerName(){
        String[] temp_counter1 = new String[2];
        String[] temp_counter2 = new String[3];
        String[] temp_counter3 = new String[5];

        for(int j = 0; j < counter1.length; j++) temp_counter1[j] = counter1[j];
        for(int j = 0; j < counter2.length; j++) temp_counter2[j] = counter2[j];
        for(int j = 0; j < counter3.length; j++) temp_counter3[j] = counter3[j];

        for(int out = 0; out < temp_counter1.length; out++){
            for(int in = 0; in < temp_counter1.length - 1; in++){
                if (temp_counter1[in].compareTo(temp_counter1[in + 1]) > 0 ){
                    String tempName = temp_counter1[in];
                    temp_counter1[in] = temp_counter1[in+1];
                    temp_counter1[in+1] = tempName;
                }
            }
        }

        for(int out = 0; out < temp_counter2.length; out++){
            for(int in = 0; in < temp_counter2.length - 1; in++){
                if (temp_counter2[in].compareTo(temp_counter2[in + 1]) > 0 ){
                    String tempName = temp_counter2[in];
                    temp_counter2[in] = temp_counter2[in+1];
                    temp_counter2[in+1] = tempName;
                }
            }
        }

        for(int out = 0; out < temp_counter3.length; out++){
            for(int in = 0; in < temp_counter3.length - 1; in++){
                if (temp_counter3[in].compareTo(temp_counter3[in + 1]) > 0 ){
                    String tempName = temp_counter3[in];
                    temp_counter3[in] = temp_counter3[in+1];
                    temp_counter3[in+1] = tempName;
                }
            }
        }

        System.out.print("Counter 1 - Sorted names : ");
        for (String name: temp_counter1)
        {
            if (!name.equals("X"))
                System.out.print(name + " ");

        }

        System.out.print("\nCounter 2 - Sorted names : ");
        for (String name: temp_counter2)
        {
            if (!name.equals("X"))
                System.out.print(name + " ");

        }

        System.out.print("\nCounter 3 - Sorted names : ");
        for (String name: temp_counter3)
        {
            if (!name.equals("X"))
                System.out.print(name + " ");

        }
        System.out.println();
    }

    public static void savedDataToFile() throws IOException{
        String holder = "";
        holder = "Counter 1 : ";
        for(int i = 0; i < counter1.length; i++){
            if (counter1[i].equals("X"))
                holder += "X ";
            else
                holder += counter1[i] + " ";
        }
        holder += "\nCounter 2 : ";
        for(int i = 0; i < counter2.length; i++){
            if (counter2[i].equals("X"))
                holder += "X ";
            else
                holder += counter2[i] + " ";
        }

        holder += "\nCounter 3 : ";
        for(int i = 0; i < counter3.length; i++){
            if (counter3[i].equals("X"))
                holder += "X ";
            else
                holder += counter3[i] + " ";
        }

        FileWriter writeObj =  new FileWriter("Sarujan.txt");
        writeObj.write(holder);
        writeObj.close();
    }

    public static void loadDataToTextFile() throws IOException{
        File readObj = new File("Sarujan.txt");

        Scanner scannerFile = new Scanner(readObj);

        while (scannerFile.hasNextLine())
            System.out.println(scannerFile.nextLine());
    }
}